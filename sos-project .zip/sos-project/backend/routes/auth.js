const router = require("express").Router();
const User = require("../models/User");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const nodemailer = require("nodemailer");

// ==========================================
// 1. REGISTER
// ==========================================
router.post("/register", async (req, res) => {
  try {

    const { email, password } = req.body;

    // ✅ EMAIL VALIDATION
    if (!validator.isEmail(email)) {
      return res.status(400).json({
        msg: "Invalid Email ❌"
      });
    }

    const existingUser = await User.findOne({ email });

    if (existingUser) {
      return res.status(400).json({
        msg: "User already exists ❌"
      });
    }

    const hashed = await bcrypt.hash(password, 10);

    const user = new User({
      email,
      password: hashed
    });

    await user.save();

    res.json({
      msg: "User registered ✅"
    });

  } catch (err) {
    console.error(err);

    res.status(500).json({
      msg: "Server error during registration"
    });
  }
});

// ==========================================
// 2. LOGIN
// ==========================================
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ msg: "User not found ❌" });

    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(400).json({ msg: "Invalid password ❌" });

    const token = jwt.sign({ id: user._id, email: user.email }, process.env.JWT_SECRET, { expiresIn: "1d" });
    res.json({ token });
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: "Server error during login" });
  }
});

// ==========================================
// 3. REQUEST OTP (FORGOT PASSWORD)
// ==========================================
router.post("/forgot-password", async (req, res) => {
  try {
    const { email } = req.body;
    const user = await User.findOne({ email });
    
    if (!user) {
      return res.status(404).json({ msg: "If that email exists, a code was sent." }); 
    }

    // 1. Generate a random 6-digit number
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    
    // 2. Save it to the database for 15 minutes
    user.resetOtp = otp;
    user.resetOtpExpires = Date.now() + 15 * 60 * 1000; 
    await user.save();

    // 3. Email the code
    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
      },
    });

    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: user.email,
      subject: "MRKHAN - Password Reset Code",
      html: `<h2>Your Password Reset Code is: <strong style="color: blue;">${otp}</strong></h2><p>This code expires in 15 minutes.</p>`
    });

    res.json({ msg: "A 6-digit code has been sent to your email! 📧" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: "Server error" });
  }
});

// ==========================================
// 4. VERIFY OTP & RESET PASSWORD
// ==========================================
router.post("/reset-password", async (req, res) => {
  try {
    const { email, otp, newPassword } = req.body;

    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ msg: "User not found." });

    if (user.resetOtp !== otp || user.resetOtpExpires < Date.now()) {
      return res.status(400).json({ msg: "Invalid or expired code ❌" });
    }

    const hashed = await bcrypt.hash(newPassword, 10);
    user.password = hashed;
    
    user.resetOtp = null;
    user.resetOtpExpires = null;
    await user.save();

    res.json({ msg: "Password updated successfully ✅ You can now log in." });
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: "Server error" });
  }
});

module.exports = router;