const router = require("express").Router();
const nodemailer = require("nodemailer");
const auth = require("../middleware/auth");
const Contact = require("../models/Contact");

// ✅ 1. Import Google Gemini
const { GoogleGenerativeAI } = require("@google/generative-ai");

// ✅ 2. Initialize Gemini with your key
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

router.post("/", auth, async (req, res) => {
  const { lat, lng } = req.body;
  // Grabs the live socket connection from your main server
  const io = req.app.get("io");

  try {
    const contacts = await Contact.find({ user: req.user.id });

    if (!contacts || contacts.length === 0) {
      return res.status(400).json({ msg: "No saved contacts found to alert. ❌" });
    }

    // ✅ 3. Generate the AI Dispatch Protocol
    let aiAnalysis = "Stay calm. Try contacting the person immediately. If unreachable, contact local authorities.";
    try {
      const model = genAI.getGenerativeModel({ model: "gemini-flash-latest" });
      const prompt = `You are an expert emergency dispatcher. A user just triggered a panic SOS button at coordinates Latitude: ${lat}, Longitude: ${lng}. Write a strict, 3-step action plan for their emergency contacts to follow right now to ensure the user's safety. Keep it under 40 words and be highly direct.`;
      
      const result = await model.generateContent(prompt);
      aiAnalysis = result.response.text();
    } catch (aiError) {
      console.error("Gemini API Error (Fallback used):", aiError.message);
    }

    // Gmail configuration
    const transporter = nodemailer.createTransport({
      service: "gmail", 
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
      },
    });

    const googleMapsLink = `https://www.google.com/maps?q=${lat},${lng}`;

    // ✅ 4. Send email to ALL contacts WITH the AI Instructions
    for (let contact of contacts) {
      if (contact.email) {
        await transporter.sendMail({
          from: process.env.EMAIL_USER,
          to: contact.email,
          subject: "🚨 URGENT: SOS ALERT 🚨",
          text: `EMERGENCY! I need help immediately.\n\nMy location: ${googleMapsLink}\n\n---\n🤖 AI DISPATCH INSTRUCTIONS:\n${aiAnalysis}`,
        });
      }
    }

    // ✅ 5. Real-time update to the frontend Map (Now includes aiAnalysis!)
    if (io) {
      io.emit("receiveSOS", { lat, lng, aiAnalysis });
    }

    res.json({ msg: "✅ SOS & AI Action Plan sent to all contacts" });

  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: "❌ Failed to send SOS" });
  }
});

module.exports = router;