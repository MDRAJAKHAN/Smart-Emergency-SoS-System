const router = require("express").Router();
const auth = require("../middleware/auth");
const Contact = require("../models/Contact"); // Make sure you have this model created!

// Add Contact
router.post("/", auth, async (req, res) => {
  try {
    const contact = new Contact({
      name: req.body.name,
      email: req.body.email,
      phone: req.body.phone,
      user: req.user.id,
    });
    await contact.save();
    res.json(contact);
  } catch (err) {
    res.status(500).json({ msg: "Error ❌" });
  }
});

// Get Contacts
router.get("/", auth, async (req, res) => {
  try {
    const contacts = await Contact.find({ user: req.user.id });
    res.json(contacts);
  } catch {
    res.status(500).json({ msg: "Error ❌" });
  }
});

// Delete Contact
router.delete("/:id", auth, async (req, res) => {
  try {
    await Contact.findByIdAndDelete(req.params.id);
    res.json({ msg: "Deleted ✅" });
  } catch {
    res.status(500).json({ msg: "Error ❌" });
  }
});

// Update Contact
router.put("/:id", auth, async (req, res) => {
  try {
    const updated = await Contact.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );
    res.json(updated);
  } catch {
    res.status(500).json({ msg: "Error ❌" });
  }
});

module.exports = router;