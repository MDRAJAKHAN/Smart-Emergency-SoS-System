require("dotenv").config(); // Loads environment variables from your .env file
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const http = require("http");
const { Server } = require("socket.io");

// 1. Initialize Express and HTTP Server
const app = express();
const server = http.createServer(app);

// 2. Configure CORS and Socket.io for your React frontend
const io = new Server(server, {
  cors: {
    origin: "http://localhost:3000", // Your React app's URL
    methods: ["GET", "POST", "PUT", "DELETE"],
  },
});

// 3. Global Middleware
app.use(cors());
app.use(express.json()); // Allows Express to parse JSON bodies

// 4. THE MAGIC LINE: Share the 'io' variable with your route files (like sos.js)
app.set("io", io); 

// 5. Connect to MongoDB
mongoose
  .connect(process.env.MONGO_URI)
  .then(() => console.log("DB Connected ✅"))
  .catch((err) => {
    console.error("Database connection error ❌:", err);
    process.exit(1); // Stop the server if the database fails to connect
  });

// 6. Import and Use Routes
app.use("/api/auth", require("./routes/auth"));
app.use("/api/contact", require("./routes/contact"));
app.use("/api/sos", require("./routes/sos"));

// 7. Handle Real-Time Socket Connections
io.on("connection", (socket) => {
  console.log(`User Connected: ${socket.id}`);

  socket.on("disconnect", () => {
    console.log(`User Disconnected: ${socket.id}`);
  });
});

// 8. Start the Server
const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT} 🚀`);
})