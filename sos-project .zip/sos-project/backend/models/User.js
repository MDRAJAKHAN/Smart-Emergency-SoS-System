const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  contacts: {
    type: [
      {
        name: String,
        email: String,
        phone: String
      }
    ],
    default: []
  },
  // ✅ ADD THESE TWO LINES FOR OTP:
  resetOtp: { type: String, default: null },
  resetOtpExpires: { type: Date, default: null }
});

module.exports = mongoose.model("User", userSchema);