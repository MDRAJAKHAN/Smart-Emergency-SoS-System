// utils/sendSMS.js

// ❌ Twilio disabled for now (to avoid error)
// const client = require("twilio")(process.env.SID, process.env.AUTH_TOKEN);

const sendSMS = async (to, msg) => {
  try {
    console.log("📩 Fake SMS sent to:", to);
    console.log("Message:", msg);
  } catch (err) {
    console.log("SMS Error:", err.message);
  }
};

module.exports = sendSMS;