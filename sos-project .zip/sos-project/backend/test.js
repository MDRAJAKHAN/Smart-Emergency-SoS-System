require("dotenv").config();

async function checkModels() {
  console.log("🔍 Asking Google for your allowed AI models...\n");
  
  const url = `https://generativelanguage.googleapis.com/v1beta/models?key=${process.env.GEMINI_API_KEY}`;
  
  try {
    const response = await fetch(url);
    const data = await response.json();
    
    if (data.error) {
      console.log("❌ Error:", data.error.message);
      return;
    }

    console.log("✅ COPY ONE OF THESE EXACT NAMES INTO YOUR SOS.JS FILE:");
    console.log("------------------------------------------------------");
    
    data.models.forEach(model => {
      // We only want models that support text generation
      if (model.supportedGenerationMethods.includes("generateContent")) {
        console.log(`👉 "${model.name.replace('models/', '')}"`);
      }
    });
    
  } catch (err) {
    console.error("❌ Fetch Error:", err.message);
  }
}

checkModels();