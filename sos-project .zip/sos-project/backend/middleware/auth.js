const jwt = require("jsonwebtoken");

module.exports = (req, res, next) => {
  let token = req.headers.authorization;

  if (!token) {
    return res.status(401).json({ msg: "No token ❌" });
  }

  // Remove "Bearer " prefix if it exists
  if (token.startsWith("Bearer ")) {
    token = token.split(" ")[1];
  }

  try {
    // Verify the token using your secret key
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next(); // Pass control to the next function (the route)
  } catch (err) {
    return res.status(401).json({ msg: "Invalid token ❌" });
  }
};