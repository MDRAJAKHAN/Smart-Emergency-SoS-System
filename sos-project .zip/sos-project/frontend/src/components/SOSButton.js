import React, { useState, useEffect } from "react";
import axios from "axios";
import io from "socket.io-client";

// Initialize socket connection
const socket = io("http://localhost:5000");

export default function SOSButton() {
  const [loading, setLoading] = useState(false);
  const [sosList, setSosList] = useState([]);

  useEffect(() => {
    socket.on("receiveSOS", (data) => {
      setSosList((prev) => [...prev, data]);
    });

    return () => socket.off("receiveSOS");
  }, []);

  const handleSendSOS = () => {
    // Vibrate phone immediately for tactile feedback
    if (navigator.vibrate) navigator.vibrate([200, 100, 200]);
    
    setLoading(true);

    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;
        const token = localStorage.getItem("token");

        try {
          // Send location to the backend
          await axios.post(
            "http://localhost:5000/api/sos",
            { lat, lng },
            {
              headers: {
                Authorization: `Bearer ${token}`, 
              },
            }
          );
          alert("🚨 SOS Broadcasted Successfully!");
        } catch (err) {
          alert("❌ " + (err.response?.data?.msg || err.message));
        }
        setLoading(false);
      },
      (err) => {
        alert("❌ Location error: Please allow location access in your browser.");
        setLoading(false);
      }
    );
  };

  return (
    <div className="w-full flex flex-col items-center">
      
      {/* ✅ The Massive 3D Tactile Button */}
      <div className="relative group flex justify-center items-center my-8">
        
        {/* Subtle background glow */}
        <div className={`absolute w-[250px] h-[250px] sm:w-[300px] sm:h-[300px] rounded-full blur-3xl -z-10 transition-all duration-300 ${loading ? 'bg-orange-500/30' : 'bg-red-600/30 group-hover:bg-red-600/50'}`}></div>

        {/* Pulsing radar ring (hides while loading) */}
        {!loading && (
          <span className="absolute w-[220px] h-[220px] sm:w-[280px] sm:h-[280px] rounded-full bg-red-500 animate-ping opacity-20 group-hover:opacity-40"></span>
        )}

        {/* The Physical Button */}
        <button
          onClick={handleSendSOS}
          disabled={loading}
          className={`relative flex items-center justify-center w-48 h-48 sm:w-64 sm:h-64 rounded-full transition-all duration-150 cursor-pointer border-4 z-10 ${
            loading
              ? "bg-gradient-to-b from-orange-400 to-orange-600 border-orange-800/30 shadow-[0_0_40px_rgba(249,115,22,0.6)] cursor-wait scale-95"
              : "bg-gradient-to-b from-red-500 to-red-700 border-red-800/30 shadow-[0_0_60px_rgba(220,38,38,0.5),inset_0_4px_15px_rgba(255,255,255,0.4)] active:scale-95 active:shadow-[0_0_20px_rgba(220,38,38,0.8),inset_0_15px_25px_rgba(0,0,0,0.6)]"
          }`}
        >
          <span className={`text-white font-black tracking-widest drop-shadow-lg relative z-10 transition-all ${loading ? 'text-2xl sm:text-3xl animate-pulse' : 'text-5xl sm:text-6xl'}`}>
            {loading ? "LOCATING..." : "SOS"}
          </span>
        </button>
      </div>

      {/* ✅ Active Alerts List */}
      {sosList.length > 0 && (
        <div className="mt-8 w-full max-w-lg bg-black/20 border border-white/10 rounded-2xl p-5 shadow-inner">
          <h3 className="font-bold text-red-400 border-b border-white/10 pb-3 flex items-center gap-2 mb-4">
            <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span> 
            Live Active Alerts
          </h3>
          <ul className="space-y-4">
            {sosList.map((s, idx) => (
              <li key={idx} className="bg-white/5 p-4 rounded-xl border border-white/5 text-sm text-gray-200 flex flex-col gap-3 shadow-lg hover:bg-white/10 transition-colors">
                
                {/* Top Row: Coordinates & Map Button */}
                <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3">
                  <div>
                    <span className="block text-xs text-gray-400 mb-1">Coordinates</span>
                    <span className="font-mono text-base">{s.lat.toFixed(4)}, {s.lng.toFixed(4)}</span>
                  </div>
                  
                  {/* ✅ FIXED: The Google Maps link format is now 100% correct */}
                  <a
                    href={`https://www.google.com/maps?q=${s.lat},${s.lng}`}
                    target="_blank"
                    rel="noreferrer"
                    className="bg-blue-600 hover:bg-blue-500 text-white px-4 py-2 rounded-lg font-bold transition-colors text-center whitespace-nowrap shadow-md"
                  >
                    📍 Open Map
                  </a>
                </div>

                {/* ✅ Bottom Row: The AI Dispatch Protocol Panel */}
                {s.aiAnalysis && (
                  <div className="mt-2 p-4 bg-indigo-900/40 border border-indigo-500/30 rounded-lg shadow-inner">
                    <h4 className="text-indigo-300 font-extrabold text-xs tracking-wider uppercase flex items-center gap-2 mb-2">
                      <span className="text-lg">🤖</span> AI Dispatch Protocol
                    </h4>
                    <p className="text-sm text-indigo-100 leading-relaxed font-medium">
                      "{s.aiAnalysis}"
                    </p>
                  </div>
                )}
                
              </li>
            ))}
          </ul>
        </div>
      )}

    </div>
  );
}