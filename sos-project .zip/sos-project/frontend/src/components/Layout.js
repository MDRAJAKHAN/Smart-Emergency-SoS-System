import React from "react";
import { Link, Outlet, useLocation } from "react-router-dom";
import ParticleBackground from "./ParticleBackground";

export default function Layout() {
  const location = useLocation();

  // Highlight the active menu link with a glowing dark glass effect
  const isActive = (path) => 
    location.pathname === path 
      ? "bg-purple-600/40 text-white border border-purple-400/50 shadow-[0_0_15px_rgba(147,51,234,0.3)]" 
      : "text-purple-200 hover:bg-white/10 hover:text-white border border-transparent";

  return (
    <div className="relative flex h-screen w-full overflow-hidden bg-gradient-to-b from-black via-[#3b0066] to-[#6a0dad]">
      
      <ParticleBackground />

      {/* ✅ Dark Glassmorphism Sidebar */}
      <aside className="w-64 bg-black/20 backdrop-blur-2xl shadow-2xl flex flex-col z-10 border-r border-white/10">
        <div className="p-6 border-b border-white/10">
          <h2 className="font-extrabold text-3xl text-white tracking-widest drop-shadow-md">
            MRKHAN
          </h2>
        </div>
        
        <nav className="flex-1 p-6 space-y-3">
          <Link
            to="/dashboard"
            className={`block px-4 py-3 rounded-xl transition-all font-semibold tracking-wide ${isActive("/dashboard")}`}
          >
            Dashboard
          </Link>
          <Link
            to="/contacts"
            className={`block px-4 py-3 rounded-xl transition-all font-semibold tracking-wide ${isActive("/contacts")}`}
          >
            Contacts
          </Link>
        </nav>
        
        <div className="p-6 border-t border-white/10">
          <button
            onClick={() => {
              localStorage.removeItem("token");
              window.location.href = "/";
            }}
            className="w-full bg-red-600/80 hover:bg-red-500 text-white px-4 py-3 font-bold rounded-xl transition-colors border border-red-500/50 shadow-[0_0_15px_rgba(220,38,38,0.3)]"
          >
            Logout
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 p-8 z-10 overflow-y-auto">
        <Outlet />
      </main>
    </div>
  );
}