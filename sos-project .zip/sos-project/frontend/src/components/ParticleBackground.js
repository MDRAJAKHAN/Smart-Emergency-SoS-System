import { useCallback } from "react";
import Particles from "react-tsparticles";
import { loadSlim } from "tsparticles-slim";

export default function ParticleBackground() {
  const particlesInit = useCallback(async (engine) => {
    await loadSlim(engine);
  }, []);

  return (
    <Particles
      id="tsparticles"
      init={particlesInit}
      style={{
        position: "absolute",
        top: 0,
        left: 0,
        width: "100%",
        height: "100%",
        zIndex: -1 
      }}
      options={{
        background: {
          color: { value: "transparent" }, // Must be transparent to show the gradient!
        },
        fpsLimit: 60,
        interactivity: {
          events: {
            onHover: {
              enable: true,
              mode: "grab", 
            },
            resize: true,
          },
          modes: {
            grab: {
              distance: 140,
              links: { opacity: 0.8 },
            },
          },
        },
        particles: {
          color: { value: "#ffffff" }, // White particles
          links: {
            color: "#ffffff", // White lines
            distance: 150,
            enable: true,
            opacity: 0.3,
            width: 1,
          },
          move: {
            direction: "none",
            enable: true,
            outModes: { default: "bounce" },
            random: false,
            speed: 0.8, 
            straight: false,
          },
          number: {
            density: { enable: true, area: 800 },
            value: 80, // Slightly more particles
          },
          opacity: { value: 0.7 },
          shape: { type: "circle" },
          size: { value: { min: 1, max: 3 } }, // Slightly larger particles
        },
        detectRetina: true,
      }}
    />
  );
}