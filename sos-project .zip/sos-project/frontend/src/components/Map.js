import React, { useState, useEffect } from "react";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import L from "leaflet";
import io from "socket.io-client";

// Fix for default map marker icons in Leaflet
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: require("leaflet/dist/images/marker-icon-2x.png"),
  iconUrl: require("leaflet/dist/images/marker-icon.png"),
  shadowUrl: require("leaflet/dist/images/marker-shadow.png"),
});

const socket = io("http://localhost:5000");

export default function Map() {
  const [locations, setLocations] = useState([]);

  useEffect(() => {
    socket.on("receiveSOS", (data) => {
      setLocations((prev) => [...prev, data]);
    });
    return () => socket.off("receiveSOS");
  }, []);

  // Default to Bengaluru!
  const center = [12.9716, 77.5946];

  return (
    <div style={{ height: "400px", width: "100%", borderRadius: "8px", overflow: "hidden" }}>
      <MapContainer center={center} zoom={12} style={{ height: "100%", width: "100%" }}>
        {/* This is the completely free map imagery from OpenStreetMap */}
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />
        
        {locations.map((loc, idx) => (
          <Marker key={idx} position={[loc.lat, loc.lng]}>
            <Popup>🚨 SOS Signal #{idx + 1}</Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  );
}