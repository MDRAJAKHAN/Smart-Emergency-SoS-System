import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import ParticleBackground from "../components/ParticleBackground";

export default function Login() {
  const [view, setView] = useState("login"); 
  
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  
  const [resetEmail, setResetEmail] = useState("");
  const [otp, setOtp] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [message, setMessage] = useState("");

  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("http://localhost:5000/api/auth/login", { email, password });
      localStorage.setItem("token", res.data.token);
      navigate("/dashboard");
    } catch (err) {
      alert("Login Failed: " + (err.response?.data?.msg || err.message));
    }
  };

  const handleSendOtp = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("http://localhost:5000/api/auth/forgot-password", { email: resetEmail });
      setMessage(res.data.msg);
      setView("reset"); 
    } catch (err) {
      setMessage(err.response?.data?.msg || "Something went wrong.");
    }
  };

  const handleVerifyAndReset = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("http://localhost:5000/api/auth/reset-password", { 
        email: resetEmail, 
        otp, 
        newPassword 
      });
      alert(res.data.msg);
      setView("login"); 
    } catch (err) {
      setMessage(err.response?.data?.msg || "Invalid code.");
    }
  };

  return (
    /* ✅ Purple Gradient Background */
    <div className="relative flex items-center justify-center h-screen w-full overflow-hidden bg-gradient-to-b from-black via-[#3b0066] to-[#6a0dad]">
      
      <ParticleBackground />

      {/* ✅ Glassmorphism White Box */}
      <div className="bg-white/90 backdrop-blur-md p-8 rounded-2xl shadow-2xl w-96 z-10 border border-white/20">
        <h2 className="text-3xl font-extrabold mb-6 text-center text-gray-800 tracking-tight">
          MRKHAN 
        </h2>

        {view === "login" && (
          <form onSubmit={handleLogin}>
            <input
              type="email" placeholder="Email" value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="border p-3 mb-4 w-full rounded-lg focus:ring-2 focus:ring-purple-500 outline-none transition-all" required
            />
            <input
              type="password" placeholder="Password" value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="border p-3 mb-2 w-full rounded-lg focus:ring-2 focus:ring-purple-500 outline-none transition-all" required
            />
            
            <div className="flex justify-end mb-4">
              <button type="button" onClick={() => { setView("forgot"); setMessage(""); }} className="text-sm text-purple-600 font-medium hover:underline">
                Forgot Password?
              </button>
            </div>

            <button type="submit" className="bg-purple-600 w-full py-3 rounded-lg text-white font-bold hover:bg-purple-700 transition-colors shadow-lg mb-3">
              Login
            </button>
            <button type="button" onClick={() => navigate("/register")} className="text-purple-600 w-full py-2 rounded-lg border border-purple-600 hover:bg-purple-50 transition-colors">
              Register Account
            </button>
          </form>
        )}

        {view === "forgot" && (
          <form onSubmit={handleSendOtp}>
            <p className="text-sm text-gray-500 mb-6 text-center italic">Enter email for a 6-digit secure code.</p>
            {message && <p className="text-center text-sm mb-4 text-red-500 font-semibold bg-red-50 p-2 rounded">{message}</p>}
            
            <input
              type="email" placeholder="Registered Email" value={resetEmail}
              onChange={(e) => setResetEmail(e.target.value)}
              className="border p-3 mb-4 w-full rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" required
            />
            <button type="submit" className="bg-purple-600 w-full py-3 rounded-lg text-white font-bold hover:bg-purple-700 shadow-lg mb-4">
              Send Reset Code
            </button>
            <button type="button" onClick={() => setView("login")} className="text-gray-500 text-sm w-full hover:text-gray-800 hover:underline">
              Back to Login
            </button>
          </form>
        )}

        {view === "reset" && (
          <form onSubmit={handleVerifyAndReset}>
            <p className="text-sm text-purple-600 mb-6 text-center font-medium">{message}</p>
            
            <input
              type="text" placeholder="6-Digit Code" value={otp} maxLength="6"
              onChange={(e) => setOtp(e.target.value)}
              className="border p-4 mb-4 w-full rounded-lg focus:ring-2 focus:ring-purple-500 outline-none text-center text-2xl tracking-[0.5em] font-black bg-gray-50" required
            />
            <input
              type="password" placeholder="New Secure Password" value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              className="border p-3 mb-4 w-full rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" required
            />
            <button type="submit" className="bg-green-600 w-full py-3 rounded-lg text-white font-bold hover:bg-green-700 shadow-lg mb-4 transition-colors">
              Update Password
            </button>
            <button type="button" onClick={() => setView("login")} className="text-gray-500 text-sm w-full hover:underline">
              Cancel
            </button>
          </form>
        )}
      </div>
    </div>
  );
}