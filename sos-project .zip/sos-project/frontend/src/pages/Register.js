import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import ParticleBackground from "../components/ParticleBackground";

export default function Register() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleRegister = async (e) => {
    e.preventDefault();
    try {
      await axios.post("http://localhost:5000/api/auth/register", { email, password });
      alert("Registration Successful! ✅");
      navigate("/");
    } catch (err) {
      alert("Registration Failed: " + (err.response?.data?.msg || err.message));
    }
  };

  return (
    <div className="relative flex items-center justify-center h-screen w-full overflow-hidden bg-gradient-to-b from-black via-[#3b0066] to-[#6a0dad]">
      
      <ParticleBackground />

      <div className="bg-white/90 backdrop-blur-md p-8 rounded-2xl shadow-2xl w-96 z-10 border border-white/20">
        <h2 className="text-3xl font-extrabold mb-6 text-center text-gray-800 tracking-tight">
          Register
        </h2>

        <form onSubmit={handleRegister}>
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="border p-3 mb-4 w-full rounded-lg focus:ring-2 focus:ring-purple-500 outline-none transition-all"
            required
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="border p-3 mb-6 w-full rounded-lg focus:ring-2 focus:ring-purple-500 outline-none transition-all"
            required
          />
          
          {/* ✅ CHANGED: Replaced green with purple to match Login */}
          <button 
            type="submit" 
            className="bg-purple-600 w-full py-3 rounded-lg text-white font-bold hover:bg-purple-700 transition-colors shadow-lg mb-3"
          >
            Create Account
          </button>
          
          <button 
            type="button" 
            onClick={() => navigate("/")} 
            className="text-gray-600 text-sm w-full hover:text-gray-900 hover:underline transition-colors font-medium"
          >
            Back to Login
          </button>
        </form>
      </div>
    </div>
  );
}