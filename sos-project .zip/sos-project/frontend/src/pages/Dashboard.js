import React from "react";
import SOSButton from "../components/SOSButton";
import Map from "../components/Map";

const Dashboard = () => {
  return (
    <div className="max-w-5xl mx-auto space-y-8 min-h-[85vh] flex flex-col items-center">
      
      {/* ✅ Command Center Card (Glassmorphism) */}
      <div className="bg-white/10 backdrop-blur-xl p-10 rounded-3xl shadow-2xl border border-white/20 flex flex-col items-center text-center w-full">
        <div>
          <h1 className="text-4xl font-extrabold text-white tracking-wide drop-shadow-md">EMERGENCY DISPATCH</h1>
          <p className="text-purple-200 mt-2 font-medium text-lg">Tap the button to immediately broadcast your location.</p>
        </div>
        
        {/* Your massive 3D SOS Button imports perfectly here */}
        <div className="w-full flex justify-center mt-6">
          <SOSButton />
        </div>
      </div>

      {/* ✅ Map Tracker Card (Glassmorphism) */}
      <div className="bg-white/10 backdrop-blur-xl p-6 rounded-3xl shadow-2xl border border-white/20 w-full">
        <div className="flex items-center justify-between mb-4 px-2">
          <h2 className="text-xl font-bold text-white">Live SOS Map</h2>
          
          {/* A cool 'GPS Active' pulsing badge */}
          <span className="flex items-center gap-2 text-sm text-green-300 font-bold bg-green-900/40 px-4 py-1.5 rounded-full border border-green-500/30 shadow-inner">
            <span className="w-2.5 h-2.5 rounded-full bg-green-400 animate-pulse"></span> Tracking Active
          </span>
        </div>
        
        {/* Map Container */}
        <div className="rounded-2xl overflow-hidden border border-white/10 shadow-inner h-[450px]">
          <Map />
        </div>
      </div>

    </div>
  );
};

export default Dashboard;