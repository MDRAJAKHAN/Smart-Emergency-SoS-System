import React, { useEffect, useState, useCallback } from "react";
import axios from "axios";
import { toast } from "react-toastify";

const Contacts = () => {
  const [contacts, setContacts] = useState([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState("");
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
  });
  const [editingId, setEditingId] = useState(null);

  const token = localStorage.getItem("token");

  // Fetch contacts
  const fetchContacts = useCallback(async () => {
    try {
      setLoading(true);
      const res = await axios.get("http://localhost:5000/api/contact", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setContacts(res.data);
    } catch {
      toast.error("Failed to load contacts");
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => {
    fetchContacts();
  }, [fetchContacts]);

  // Add / Update contact
  const handleSubmit = async () => {
    if (!form.name || !form.email || !form.phone) {
      toast.error("Fill all fields ❌");
      return;
    }

    try {
      if (editingId) {
        // UPDATE
        await axios.put(
          `http://localhost:5000/api/contact/${editingId}`,
          form,
          { headers: { Authorization: `Bearer ${token}` } }
        );
        toast.success("Contact Updated ✅");
      } else {
        // ADD
        await axios.post("http://localhost:5000/api/contact", form, {
          headers: { Authorization: `Bearer ${token}` },
        });
        toast.success("Contact Added ✅");
      }

      // reset
      setForm({ name: "", email: "", phone: "" });
      setEditingId(null);
      fetchContacts();
    } catch {
      toast.error("Operation failed ❌");
    }
  };

  // Delete
  const deleteContact = async (id) => {
    if (!window.confirm("Delete this contact?")) return;

    try {
      await axios.delete(`http://localhost:5000/api/contact/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      toast.success("Deleted 🗑️");
      fetchContacts();
    } catch {
      toast.error("Delete failed ❌");
    }
  };

  // Edit 
  const editContact = (c) => {
    setForm({
      name: c.name,
      email: c.email,
      phone: c.phone,
    });
    setEditingId(c._id); 
  };

  // Search filter
  const filtered = contacts.filter((c) =>
    c.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <h1 className="text-3xl font-extrabold text-white tracking-wide text-center drop-shadow-md mb-8">
        📇 Contacts Manager
      </h1>

      {/* ✅ Search Bar (Glassmorphism) */}
      <div className="bg-white/10 backdrop-blur-xl p-2 rounded-2xl shadow-lg border border-white/20">
        <input
          className="w-full bg-transparent border-none p-3 text-white placeholder-purple-300 focus:outline-none focus:ring-0 text-lg"
          placeholder="Search contacts by name..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {/* ✅ Form (Glassmorphism) */}
      <div className="bg-white/10 backdrop-blur-xl p-4 rounded-2xl shadow-lg border border-white/20 flex flex-col md:flex-row gap-4">
        <input
          className="flex-1 bg-black/20 border border-white/10 rounded-xl p-3 text-white placeholder-gray-400 focus:outline-none focus:border-purple-500 transition-colors"
          placeholder="Name"
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
        />
        <input
          className="flex-1 bg-black/20 border border-white/10 rounded-xl p-3 text-white placeholder-gray-400 focus:outline-none focus:border-purple-500 transition-colors"
          placeholder="Email"
          type="email"
          value={form.email}
          onChange={(e) => setForm({ ...form, email: e.target.value })}
        />
        <input
          className="flex-1 bg-black/20 border border-white/10 rounded-xl p-3 text-white placeholder-gray-400 focus:outline-none focus:border-purple-500 transition-colors"
          placeholder="Phone"
          value={form.phone}
          onChange={(e) => setForm({ ...form, phone: e.target.value })}
        />

        <button
          onClick={handleSubmit}
          className={`px-8 py-3 rounded-xl text-white font-bold transition-all shadow-lg ${
            editingId
              ? "bg-yellow-600 hover:bg-yellow-500 shadow-[0_0_15px_rgba(202,138,4,0.4)]"
              : "bg-purple-600 hover:bg-purple-500 shadow-[0_0_15px_rgba(147,51,234,0.4)]"
          }`}
        >
          {editingId ? "Update" : "Add"}
        </button>

        {editingId && (
          <button
            onClick={() => {
              setEditingId(null);
              setForm({ name: "", email: "", phone: "" });
            }}
            className="bg-gray-600 text-white px-6 py-3 rounded-xl hover:bg-gray-500 transition-colors font-bold"
          >
            Cancel
          </button>
        )}
      </div>

      {/* ✅ Loader & Contacts Grid */}
      {loading ? (
        <p className="text-center font-semibold text-purple-200 mt-8">Loading contacts...</p>
      ) : filtered.length === 0 ? (
        <p className="text-center text-purple-300 mt-8">No contacts found.</p>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
          {filtered.map((c) => (
            <div
              key={c._id}
              className="bg-white/5 backdrop-blur-md border border-white/10 p-6 rounded-2xl shadow-xl hover:bg-white/10 transition-all group flex flex-col"
            >
              <h3 className="text-xl font-bold text-white mb-3">{c.name}</h3>
              
              <div className="space-y-2 mb-6">
                <p className="text-purple-200 flex items-center gap-2 text-sm">
                  <span className="bg-white/10 p-1.5 rounded-md">📧</span> {c.email}
                </p>
                <p className="text-purple-200 flex items-center gap-2 text-sm">
                  <span className="bg-white/10 p-1.5 rounded-md">📱</span> {c.phone}
                </p>
              </div>

              <div className="flex justify-end gap-4 mt-auto pt-4 border-t border-white/10">
                <button
                  onClick={() => editContact(c)}
                  className="text-blue-400 hover:text-blue-300 font-semibold text-sm transition-colors"
                >
                  Edit
                </button>
                <button
                  onClick={() => deleteContact(c._id)}
                  className="text-red-400 hover:text-red-300 font-semibold text-sm transition-colors"
                >
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Contacts;