import React, { useState } from "react";
import axios from "axios";
import { useNavigate, useParams } from "react-router-dom";

export default function ResetPassword() {
  const [newPassword, setNewPassword] = useState("");
  const navigate = useNavigate();
  const { token } = useParams(); // Grabs the secret token from the URL

  const handleResetSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post(`http://localhost:5000/api/auth/reset-password/${token}`, { newPassword });
      alert("Password successfully reset! You can now log in.");
      navigate("/");
    } catch (err) {
      alert("Reset Failed: " + (err.response?.data?.msg || "Invalid or expired token."));
    }
  };

  return (
    <div className="flex items-center justify-center h-screen bg-gray-100">
      <form onSubmit={handleResetSubmit} className="bg-white p-8 rounded shadow w-96">
        <h2 className="text-2xl font-bold mb-4 text-center">Create New Password</h2>
        <input
          type="password"
          placeholder="New Password"
          value={newPassword}
          onChange={(e) => setNewPassword(e.target.value)}
          className="border p-2 mb-6 w-full rounded"
          required
        />
        <button type="submit" className="bg-green-500 w-full py-2 rounded text-white hover:bg-green-600">
          Save New Password
        </button>
      </form>
    </div>
  );
}