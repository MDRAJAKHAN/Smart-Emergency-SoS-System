import React from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";

// Pages
import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import Contacts from "./pages/Contacts";

// We keep ResetPassword because they still need a page to type their new password!
import ResetPassword from "./pages/ResetPassword";

// Components
import Layout from "./components/Layout";

// Protection Logic
const ProtectedRoute = ({ children }) => {
  const token = localStorage.getItem("token");
  if (!token) return <Navigate to="/" replace />;
  return children;
};

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* === PUBLIC ROUTES === */}
        <Route path="/" element={<Login />} />
        <Route path="/register" element={<Register />} /> 
        
        {/* The link from the email will send users here: */}
        <Route path="/reset-password/:token" element={<ResetPassword />} />

        {/* === PROTECTED ROUTES === */}
        <Route
          element={
            <ProtectedRoute>
              <Layout />
            </ProtectedRoute>
          }
        >
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/contacts" element={<Contacts />} />
        </Route>

        {/* Catch-all: sends unknown URLs back to login */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}